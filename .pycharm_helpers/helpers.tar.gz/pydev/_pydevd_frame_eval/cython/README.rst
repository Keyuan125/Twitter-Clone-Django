Version specific frame evaluation code. The right module will be picked up
during the build process.

The folder name format
``<major_version><minor_version>_<major_version><minor_version>`` defines
the Python version range for which the modules in the folder are suitable
for.